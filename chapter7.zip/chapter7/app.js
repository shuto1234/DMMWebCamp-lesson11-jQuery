
for (let i = 1; i < 51; i++){

  if (10 == i){
    console.log("今" +i+ "回ループしました。");
  }else if (20 == i){
    console.log("今" +i+ "回ループしました。");
  }else if (30 == i){
    console.log("今" +i+ "回ループしました。");
  }else if (40 == i){
    console.log("今" +i+ "回ループしました。");
  }else if (50 == i){
    console.log("今" +i+ "回ループしました。");
  }

  switch (i % 4){
    case 0:
      console.log("4で割れる数です。" +i);
      break;
  }

  if (i == 50){
    alert(i+ "回カウントが終わりました。")
  }
}
